本文件夹是实现三个模块的launch文件

empty.launch：空launch文件，添加了开头和结尾

1.SLAM建图（用的是gmapping算法）
	1.1启动建图：nav_slam.launch
	1.2保存建好的地图：map_save.launch

2.amcl定位
	2.1加载地图：map_load.launch（不用单独运行，已经集成进两个test_xxx.launch中了）
	2.2加载amcl参数：nav_amcl.launch（不用单独运行，已经集成进两个test_xxx.launch中了）
	2.3启动amcl定位：test_amcl.launch

3.move_base路径规划
	3.1加载参数：path.launch（不用单独运行，已经集成进test_move_base.launch中了）
	3.2启动自主导航：test_move_base.launch