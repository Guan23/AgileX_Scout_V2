本文件夹保存的是move_base模块用到的各种.yaml参数文件

1.代价地图：
	1.1全局代价地图：global_costmap_params.yaml
	1.2局部代价地图：local_costmap_params.yaml
	1.3代价地图通用参数：costmap_common_params.yaml

2.路径规划：
	2.1全局路径规划：global_planner_params.yaml
	2.2局部路径规划：base_local_planner_params.yaml/dwa_local_planner_params.yaml

3.move_base通用参数：move_base_params.yaml
