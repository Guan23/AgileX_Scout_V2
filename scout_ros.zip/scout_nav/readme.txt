
说明：

本功能包主要实现ROS三个模块的功能：SLAM建图（用的是gmapping算法），amcl定位和move_base路径规划

1.config文件夹存放的是move_base用到的yaml参数文件

2.launch文件夹存放的是三个模块的launch文件

3.map文件夹存放的是gazebo里绘制的地图文件