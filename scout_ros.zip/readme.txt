说明文档：

1. 除了scout_nav以外，其他包都是官方自带的，scout_nav是我自定义的功能包，里面包含了三个模块，分别是gmapping建图，amcl定位和move_base路径规划

2. scout_bringup有加载小车的launch文件，scout_description是小车的xacro描述文件，我再里面的scout_description/urdf/my_extra里也添加了一些自定义的组件

3. 松灵官方写了scout的驱动，在scout_gazebo_sim/src下面的两个.cpp文件中，测试的时候也可以用planar_move代替

4. 测试步骤：
	1. 先启动gazebo仿真和rviz可视化环境：
	roslaunch scout_bringup scout_base_gazebo_sim.launch
	2. 测试自主导航功能：
	roslaunch scout_nav test_base_move.launch
	3. 如需更换地图，则更改两个launch文件
		3.1 scout_gazebo_sim/launch/scout_empty_world.launch开头的world_name参数（修改gazebo中的world）
		3.2 scout_nav/launch/map_load.launch开头的filename参数（修改rviz中的map）
